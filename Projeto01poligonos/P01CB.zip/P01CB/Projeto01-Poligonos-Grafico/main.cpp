#include "retangulo.h"
#include "poligono.h"
#include "miniwin.h"
#include <iostream>
using namespace miniwin;
using namespace std;
#include <stdio.h>
#include <stdlib.h>
void desenha(Poligono R){
Ponto v[10];
   for(int i=0; i<10; i++){
        int x=((R.a[i].getX())*25+250);
        int y=((-R.a[i].getY())*25+250);

   v[i].setXY(x,y);
   }
   v[10].setXY((R.a[0].getX())*25+250,(-R.a[0].getY())*25+250);
   for(int i=0; i<10; i++){
   linea(v[i].getX(),v[i].getY(),v[i+1].getX(),v[i+1].getY());
   }
}
int main() {
   vredimensiona(640, 640);
   //linha do eixo y
   linea(250,0,250,500);
   //linha do eixo x
 linea(0,250,500,250);

 //DESENHA POLIGONOS;
     Poligono P=10;
   float vx[10]={0,1,4,2,3,0,-3,-2,-4,-1};
   float vy[10]={5,2,2,0,-3,-1,-3,0,2,2};
    for(int i=0; i<10; i++){
        P.a[i].setXY(vx[i],vy[i]);
 }
    /*P.print();
    P.area();
    P.centrodegravidade();
    desenha(P);
    P.rotaciona(6.7,4.0,30);
    P.area();
    P.centrodegravidade();
    desenha(P);
    P.rotaciona(6.7,4.0,60);
    P.area();
    P.centrodegravidade();
    desenha(P);
    P.translada(1,1);
    P.centrodegravidade(); */
  /* /Retangulo R(0,0,4,3);
   desenha(R);
    //R.translada(-2,-2);
    for(int i=0; i<3; i++){
    R.rotaciona(2,-1.5,30);
    desenha(R);
} */
    //R.rotaciona(2,-1.5,90);
    //desenha(R);
    //R.translada(2,2);
   // R.translada(2,-1.5);


   //for(int i=0; i<10; i++){
   //     int x=((rand()%10)*25+250);
    //    int y=((-rand()%10)*25+250);

   //punto(x,y);
   //}
    for(int i=25; i<500; i=i+25){
   linea(i,245,i,255);
   }
    for(int i=25; i<500; i=i+25){
   linea(245,i,255,i);
   }
    punto((2)*25+250,-(-1.5)*25+250);
   //rectangulo(100, 100, 300, 200);

   //for(int i=0; i<10; i++){
   texto(250, 260, "0");
   texto(275, 260, "1");
   texto(300, 260, "2");
   texto(325, 260, "3");
   texto(350, 260, "4");
    texto(375, 260, "5");
    texto(400, 260, "6");
   texto(425, 260, "7");
   texto(450, 260, "8");
   texto(475, 260, "9");

     texto(220, 260, "-1");
   texto(195, 260, "-2");
   texto(170, 260, "-3");
   texto(145, 260, "-4");
    texto(120, 260, "-5");
     texto(95, 260, "-6");
   texto(70, 260, "-7");
   texto(45, 260, "-8");
   texto(20, 260, "-9");
   //}
   int h=1,t=0;
while(h>0){
    cout<<"digite 0-sair, 1-Rotacionar, 2-transladar\n";
    cin>>h;
    if(h==1){
    P.rotaciona(0,0,t);
    desenha(P);
    refresca();
    P.area();
    P.centrodegravidade();
    P.rotaciona(0,0,-t);
    t=t+30;
    }
    if(h==2){
        P.translada(2,2);
        desenha(P);
        refresca();

    }
    if(h==0){
         h=0;
        exit(0);
    }
}
   return 0;
}
