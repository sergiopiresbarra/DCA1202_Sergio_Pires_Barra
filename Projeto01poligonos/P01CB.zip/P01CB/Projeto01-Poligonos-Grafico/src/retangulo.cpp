#include "retangulo.h"


Retangulo::~Retangulo()
{
    //dtor
}
